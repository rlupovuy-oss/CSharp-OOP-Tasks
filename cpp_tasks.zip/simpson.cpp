#include <iostream>
#include <cmath>
using namespace std;

double f(double x)
{
    return sin(x);
}

double simpson(double a, double b, int n)
{
    double h = (b - a) / n;
    double sum = f(a) + f(b);

    for(int i = 1; i < n; i++)
    {
        double x = a + i * h;
        if(i % 2 == 0) sum += 2 * f(x);
        else sum += 4 * f(x);
    }

    return sum * h / 3;
}

int main()
{
    double a, b;
    int n;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "n (парне) = "; cin >> n;

    if(n % 2 != 0) n++;

    cout << "Інтеграл = " << simpson(a, b, n);

    return 0;
}
