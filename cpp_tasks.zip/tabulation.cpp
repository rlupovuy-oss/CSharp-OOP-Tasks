#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double a, b, h;
    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "h = "; cin >> h;

    cout << "x\tf(x)\n";

    for(double x = a; x <= b; x += h)
    {
        cout << x << "\t" << sin(x) << endl;
    }

    return 0;
}
