using System;
using System.Linq;

class Student
{
    public string Name { get; set; }
    public string Group { get; set; }
    public int[] Grades { get; set; }

    public double Average => Grades.Average();
    public bool OnlyHighMarks => Grades.All(g => g >= 4);

    public void PrintInfo()
    {
        Console.WriteLine($"{Name}, група {Group}, середній бал: {Average:F2}");
    }
}

class ProgramStudent
{
    static void Main()
    {
        Student[] students = new Student[]
        {
            new Student { Name = "Роман Липовий", Group = "AIК-43", Grades = new int[]{5, 5, 4, 5, 5} },
            new Student { Name = "Влад Нагорний", Group = "AIК-43", Grades = new int[]{3, 4, 4, 3, 4} },
            new Student { Name = "Ігор Петренко", Group = "AIК-42", Grades = new int[]{5, 5, 5, 5, 5} }
        };

        Console.WriteLine("Студенти, відсортовані за середнім балом:");
        foreach (var st in students.OrderBy(s => s.Average))
            st.PrintInfo();

        Console.WriteLine("\nСтуденти з оцінками лише 4 або 5:");
        foreach (var st in students.Where(s => s.OnlyHighMarks))
            Console.WriteLine($"{st.Name} ({st.Group})");
    }
}