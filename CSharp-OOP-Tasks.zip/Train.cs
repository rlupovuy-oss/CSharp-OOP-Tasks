using System;
using System.Linq;

class Train
{
    public string Destination { get; set; }
    public int Number { get; set; }
    public TimeSpan DepartureTime { get; set; }

    public void Print()
    {
        Console.WriteLine($"Поїзд №{Number}: {Destination}, відправлення о {DepartureTime}");
    }
}

class ProgramTrain
{
    static void Main()
    {
        Train[] trains = new Train[]
        {
            new Train { Destination = "Київ", Number = 102, DepartureTime = new TimeSpan(8, 15, 0) },
            new Train { Destination = "Львів", Number = 54, DepartureTime = new TimeSpan(10, 0, 0) },
            new Train { Destination = "Київ", Number = 83, DepartureTime = new TimeSpan(9, 30, 0) },
            new Train { Destination = "Одеса", Number = 45, DepartureTime = new TimeSpan(7, 45, 0) },
            new Train { Destination = "Харків", Number = 21, DepartureTime = new TimeSpan(6, 0, 0) }
        };

        Console.WriteLine("Сортування за номером поїзда:");
        foreach (var t in trains.OrderBy(t => t.Number))
            t.Print();

        Console.Write("\nВведіть номер поїзда для пошуку: ");
        int num = int.Parse(Console.ReadLine());
        var train = trains.FirstOrDefault(t => t.Number == num);
        if (train != null)
            train.Print();
        else
            Console.WriteLine("Поїзд не знайдено.");

        Console.WriteLine("\nСортування за пунктом призначення та часом:");
        foreach (var t in trains.OrderBy(t => t.Destination).ThenBy(t => t.DepartureTime))
            t.Print();
    }
}